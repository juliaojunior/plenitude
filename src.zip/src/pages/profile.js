import { useSession, signOut } from 'next-auth/react';
import { useRouter } from 'next/router';
import { useEffect, useState } from 'react';
import styled from 'styled-components';
import { motion } from 'framer-motion';
import { FaCog, FaHistory, FaHeart, FaBell, FaSignOutAlt } from 'react-icons/fa';
import Head from 'next/head';
import Navbar from '../components/Navbar';
import ProfileHeader from '../components/ProfileHeader';

const Container = styled.div`
  min-height: 100vh;
  background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
  color: #fff;
`;

const Content = styled.div`
  padding: 1.5rem;
  padding-bottom: 5rem; // Espaço para a navbar
`;

const StatsContainer = styled.div`
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 1rem;
  margin-bottom: 2rem;
`;

const StatCard = styled.div`
  background: rgba(255, 255, 255, 0.1);
  border-radius: 15px;
  padding: 1.2rem;
  text-align: center;
  
  h3 {
    font-size: 2rem;
    margin-bottom: 0.5rem;
    color: #7251b5;
  }
  
  p {
    font-size: 0.9rem;
    color: rgba(255, 255, 255, 0.7);
  }
`;

const MenuList = styled.div`
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  margin-bottom: 2rem;
`;

const MenuItem = styled(motion.div)`
  display: flex;
  align-items: center;
  padding: 1rem;
  background: rgba(255, 255, 255, 0.05);
  border-radius: 12px;
  cursor: pointer;
  
  &:hover {
    background: rgba(255, 255, 255, 0.1);
  }
  
  svg {
    font-size: 1.2rem;
    margin-right: 1rem;
    color: ${props => props.iconColor || '#7251b5'};
  }
  
  .label {
    flex: 1;
  }
  
  .arrow {
    color: rgba(255, 255, 255, 0.5);
  }
`;

const LogoutButton = styled(motion.button)`
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.5rem;
  width: 100%;
  padding: 1rem;
  background: rgba(238, 82, 83, 0.2);
  border: none;
  border-radius: 12px;
  color: #ff6b6b;
  font-weight: 600;
  margin-top: 2rem;
  cursor: pointer;
  
  &:hover {
    background: rgba(238, 82, 83, 0.3);
  }
`;

export default function Profile() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [stats, setStats] = useState({ days: 0, minutes: 0 });
  
  // Redirecionar para login se não estiver autenticado
  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/login');
    }
    
    // Dados simulados para estatísticas
    if (status === 'authenticated') {
      setStats({
        days: 15,
        minutes: 145
      });
    }
  }, [status, router]);

  const handleLogout = () => {
    signOut({ callbackUrl: '/login' });
  };

  if (status === 'loading' || status === 'unauthenticated') {
    return (
      <Container>
        <Head>
          <title>Carregando - Plenitude</title>
        </Head>
        <div style={{ 
          display: 'flex', 
          justifyContent: 'center', 
          alignItems: 'center',
          height: '100vh'
        }}>
          Carregando...
        </div>
      </Container>
    );
  }

  return (
    <Container>
      <Head>
        <title>Perfil - Plenitude</title>
        <meta name="description" content="Seu perfil no aplicativo de meditação cristã Plenitude" />
      </Head>
      
      <Content>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <ProfileHeader 
            name={session.user.name || 'Usuário'}
            email={session.user.email}
            image={session.user.image || 'https://via.placeholder.com/100'}
          />
          
          <StatsContainer>
            <StatCard>
              <h3>{stats.days}</h3>
              <p>Dias meditando</p>
            </StatCard>
            <StatCard>
              <h3>{stats.minutes}</h3>
              <p>Minutos totais</p>
            </StatCard>
          </StatsContainer>
          
          <MenuList>
            <MenuItem whileTap={{ scale: 0.98 }}>
              <FaHistory />
              <span className="label">Histórico de meditações</span>
              <span className="arrow">></span>
            </MenuItem>
            
            <MenuItem whileTap={{ scale: 0.98 }} iconColor="#4cc9f0">
              <FaHeart />
              <span className="label">Meditações favoritas</span>
              <span className="arrow">></span>
            </MenuItem>
            
            <MenuItem whileTap={{ scale: 0.98 }} iconColor="#f72585">
              <FaBell />
              <span className="label">Lembretes diários</span>
              <span className="arrow">></span>
            </MenuItem>
            
            <MenuItem whileTap={{ scale: 0.98 }} iconColor="#4361ee">
              <FaCog />
              <span className="label">Configurações</span>
              <span className="arrow">></span>
            </MenuItem>
          </MenuList>
          
          <LogoutButton 
            whileTap={{ scale: 0.98 }}
            onClick={handleLogout}
          >
            <FaSignOutAlt />
            Sair da conta
          </LogoutButton>
        </motion.div>
      </Content>
      
      <Navbar />
    </Container>
  );
}
